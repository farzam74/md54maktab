<?php

        //this file created to refresh privatechat page when clicked on a contact in contacts page to show receiver chat page instantly.
        header("Location: privatechat.php");
        exit();