<?php 

//this file created to show edited details just after user submit edit without need to refresh to see edited details
header("Location: profile.php");
exit();